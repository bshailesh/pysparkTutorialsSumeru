# Databricks notebook source
# MAGIC %md 
# MAGIC # Create pandas DataFrame from List

# COMMAND ----------

import pandas as pd
column_names=["Courses","Fee","Duration"]
technologies = [ ["Spark",20000, "30days"], 
                 ["Pandas",25000, "40days"], 
               ]
row_label=["a","b"]
df=pd.DataFrame(technologies,columns=column_names,index=row_label)
print(df)

types={'Courses': str,'Fee':float,'Duration':str}
df=df.astype(types)

# COMMAND ----------

# MAGIC %md 
# MAGIC #Create DataFrame from the Dic (dictionary).

# COMMAND ----------

technologies = {
    'Courses':["Spark","Pandas"],
    'Fee' :[20000,25000],
    'Duration':['30days','40days']
              }
df = pd.DataFrame(technologies)
print(df)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Create DataFrame with Index

# COMMAND ----------

technologies = {
    'Courses':["Spark","Pandas"],
    'Fee' :[20000,25000],
    'Duration':['30days','40days']
              }
index_label=["r1","r2"]
df = pd.DataFrame(technologies, index=index_label)
print(df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Creates DataFrame from list of dict

# COMMAND ----------

technologies = [{'Courses':'Spark', 'Fee': 20000, 'Duration':'30days'},
        {'Courses':'Pandas', 'Fee': 25000, 'Duration': '40days'}]

df = pd.DataFrame(technologies)
print(df)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Create Dataframe using Series

# COMMAND ----------

# Create pandas Series
courses = pd.Series(["Spark","Pandas"])
fees = pd.Series([20000,25000])
duration = pd.Series(['30days','40days'])

# Create DataFrame from series objects.
df=pd.concat([courses,fees,duration],axis=1)
print(df)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Create Series from array

# COMMAND ----------

import pandas as pd 
import numpy as np
data = np.array(['python','php','java'])
series = pd.Series(data)
print (series)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Create a Dict from Input

# COMMAND ----------

# Create a Dict from a input
data = {'Courses' :"pandas", 'Fees' : 20000, 'Duration' : "30days"}
s2 = pd.Series(data)
print (s2)

# COMMAND ----------

# MAGIC %md
# MAGIC # Creating DataFrame from List

# COMMAND ----------

#Creating DataFrame from List
data = ['python','php','java']
s2 = pd.Series(data, index=['r1', 'r2','r3'])
print(s2)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Prepare PySpark DataFrame

# COMMAND ----------

# DBTITLE 1,Prepare PySpark DataFrame
data = [("James","","Smith","36636","M",60000),
        ("Michael","Rose","","40288","M",70000),
        ("Robert","","Williams","42114","",400000),
        ("Maria","Anne","Jones","39192","F",500000),
        ("Jen","Mary","Brown","","F",0)]

columns = ["first_name","middle_name","last_name","dob","gender","salary"]
pysparkDF = spark.createDataFrame(data = data, schema = columns)
pysparkDF.printSchema()
pysparkDF.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Covert Spark Data Frame to Pandas Dataframe

# COMMAND ----------

pandasDF = pysparkDF.toPandas()
print(pandasDF)