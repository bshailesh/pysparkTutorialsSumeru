# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC # PySpark Join 
# MAGIC is used to combine two DataFrames and by chaining these you can join multiple DataFrames; it supports all basic join type operations available in traditional SQL like INNER, LEFT OUTER, RIGHT OUTER, LEFT ANTI, LEFT SEMI, CROSS, SELF JOIN. PySpark Joins are wider transformations that involve data shuffling across the network.

# COMMAND ----------

emp = [(1,"Smith",-1,"2018","10","M",3000), \
    (2,"Rose",1,"2010","20","M",4000), \
    (3,"Williams",1,"2010","10","M",1000), \
    (4,"Jones",2,"2005","10","F",2000), \
    (5,"Brown",2,"2010","40","",-1), \
      (6,"Brown",2,"2010","50","",-1) \
  ]
empColumns = ["emp_id","name","superior_emp_id","year_joined", "emp_dept_id","gender","salary"]

empDF = spark.createDataFrame(data=emp, schema = empColumns)
empDF.printSchema()
empDF.display()

dept = [("Finance",10), \
    ("Marketing",20), \
    ("Sales",30), \
    ("IT",40) \
  ]
deptColumns = ["dept_name","dept_id"]
deptDF = spark.createDataFrame(data=dept, schema = deptColumns)
deptDF.printSchema()
deptDF.display()

# COMMAND ----------

# empDF/deptDF - select * from empDF e join deptDf d on e.emp_dept_id = d.dept_id
# firstDataFrame.join(SeconDataFrame,FirstDataFrame.ColumnUsedForJoin ==  SecondDataFrame.ColumnUsedForJoin,"JoinType")
empDF.join(deptDF,empDF.emp_dept_id ==  deptDF.dept_id,"inner").display()

# COMMAND ----------

empDF.join(deptDF,empDF.emp_dept_id ==  deptDF.dept_id,"right").display()

# COMMAND ----------

empDF.join(deptDF,empDF.emp_dept_id ==  deptDF.dept_id,"outer").display()

empDF.join(deptDF,empDF.emp_dept_id ==  deptDF.dept_id,"full").display()

empDF.join(deptDF,empDF.emp_dept_id ==  deptDF.dept_id,"fullouter").display()

# COMMAND ----------

empDF.createOrReplaceTempView("EMP")
deptDF.createOrReplaceTempView("DEPT")

joinDF = spark.sql("select * from EMP e, DEPT d where e.emp_dept_id == d.dept_id") \
  .show(truncate=False)

joinDF2 = spark.sql("select * from EMP e INNER JOIN DEPT d ON e.emp_dept_id == d.dept_id") \
  .show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC # Union & UnionAll

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession

simpleData = [("James","Sales","NY",90000,34,10000), \
    ("Michael","Sales","NY",86000,56,20000), \
    ("Robert","Sales","CA",81000,30,23000), \
    ("Maria","Finance","CA",90000,24,23000) \
  ]

columns= ["employee_name","department","state","salary","age","bonus"]
df = spark.createDataFrame(data = simpleData, schema = columns)
df.display()

simpleData2 = [("James","Sales","NY",90000,34,10000), \
    ("Maria","Finance","CA",90000,24,23000), \
    ("Jen","Finance","NY",79000,53,15000), \
    ("Jeff","Marketing","CA",80000,25,18000), \
    ("Kumar","Marketing","NY",91000,50,21000) \
  ]
columns2= ["employee_name","department","state","salary","age","bonus"]

df2 = spark.createDataFrame(data = simpleData2, schema = columns2)
df2.display()

unionDF = df.union(df2)
unionDF.display()
disDF = df.union(df2).distinct()
disDF.display()

unionAllDF = df.unionAll(df2)
unionAllDF.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #unionByName
# MAGIC The pyspark.sql.DataFrame.unionByName() to merge/union two DataFrames with column names. In PySpark you can easily achieve this using unionByName() transformation, this function also takes param allowMissingColumns with the value True if you have a different number of columns on two DataFrames.

# COMMAND ----------

from pyspark.sql import SparkSession

# Create DataFrame df1 with columns name, and id
data = [("James",34), ("Michael",56), \
        ("Robert",30), ("Maria",24) ]

df1 = spark.createDataFrame(data = data, schema=["name","id"])
df1.printSchema()

# Create DataFrame df2 with columns name and id
data2=[(34,"James"),(45,"Maria"), \
       (45,"Jen"),(34,"Jeff")]

df2 = spark.createDataFrame(data = data2, schema = ["id","name"])
df2.printSchema()

df4 = df1.union(df2)
df4.display()

# unionByName() example
df3 = df1.unionByName(df2)
df3.printSchema
df3.display()