# Databricks notebook source
# MAGIC %md
# MAGIC # RDD (Resilient Distributed Dataset) 
# MAGIC   is a fundamental building block of PySpark which is fault-tolerant, immutable distributed collections of objects. Immutable meaning once you create an RDD you cannot change it. Each record in RDD is divided into logical partitions, which can be computed on different nodes of the cluster. 
# MAGIC 
# MAGIC In other words, RDDs are a collection of objects similar to list in Python, with the difference being RDD is computed on several processes scattered across multiple physical servers also called nodes in a cluster while a Python collection lives and process in just one process.
# MAGIC 
# MAGIC Additionally, RDDs provide data abstraction of partitioning and distribution of the data designed to run computations in parallel on several nodes, while doing transformations on RDD we don’t have to worry about the parallelism as PySpark by default provides.
# MAGIC 
# MAGIC # PySpark RDD Benefits
# MAGIC   - PySpark is widely adapted in Machine learning and Data science community due to it’s advantages compared with traditional python programming.
# MAGIC 
# MAGIC ### In-Memory Processing
# MAGIC   - PySpark loads the data from disk and process in memory and keeps the data in memory, this is the main difference between PySpark and Mapreduce (I/O intensive). In between the transformations, we can also cache/persists the RDD in memory to reuse the previous computations.
# MAGIC   
# MAGIC ### Immutability
# MAGIC   - PySpark RDD’s are immutable in nature meaning, once RDDs are created you cannot modify. When we apply transformations on RDD, PySpark creates a new RDD and maintains the RDD Lineage.
# MAGIC 
# MAGIC ### Fault Tolerance
# MAGIC   - PySpark operates on fault-tolerant data stores on HDFS, S3 e.t.c hence any RDD operation fails, it automatically reloads the data from other partitions. Also, When PySpark applications running on a cluster, PySpark task failures are automatically recovered for a certain number of times (as per the configuration) and finish the application seamlessly.
# MAGIC 
# MAGIC ### Lazy Evolution
# MAGIC   - PySpark does not evaluate the RDD transformations as they appear/encountered by Driver instead it keeps the all transformations as it encounters(DAG) and evaluates the all transformation when it sees the first RDD action.
# MAGIC 
# MAGIC ### Partitioning
# MAGIC   - When you create RDD from a data, It by default partitions the elements in a RDD. By default it partitions to the number of cores available.

# COMMAND ----------

# DBTITLE 1,Create RRD using Parallelize
#Create RDD from parallelize    
data = [1,2,3,4,5,6,7,8,9,10,11,12]
rdd=spark.sparkContext.parallelize(data)
print("initial partition count:"+str(rdd.getNumPartitions()))

rdd2 = spark.sparkContext.parallelize(data,10) 
print("initial partition count:"+str(rdd2.getNumPartitions()))

reparRdd = rdd.repartition(4)
print("re-partition count:"+str(reparRdd.getNumPartitions()))

# COMMAND ----------

# Create spark session with local[5]
rdd = spark.sparkContext.parallelize(range(0,20))
print("From local[5] : "+str(rdd.getNumPartitions()))

# Use parallelize with 6 partitions
rdd1 = spark.sparkContext.parallelize(range(0,25), 6)
print("parallelize : "+str(rdd1.getNumPartitions()))

rdd2 = spark.sparkContext.parallelize(range(0,25), 6)

# COMMAND ----------

dept = [("Finance",10),("Marketing",20),("Sales",30),("IT",40)]
deptColumns = ["dept_name","dept_id"]
rdd = spark.sparkContext.parallelize(dept)
df = rdd.toDF(deptColumns) # Convert the rdd into Dataframe
df.printSchema()
df.show(truncate=False)

# COMMAND ----------

UserName=dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
dataset_path = f"dbfs:/FileStore/shared_uploads/{UserName}/products.csv"
print(dataset_path)

df = spark.read.format("csv") \
  .option("header", "true") \
  .option("inferSchema", "true") \
  .load(f"dbfs:/FileStore/shared_uploads/{UserName}/products.csv")
df.display()
df.createOrReplaceTempView("products")
# Default - displays 20 rows and 
# 20 charactes from column value 
df.show()

#Display full column contents
df.show(truncate=False)

# Display 2 rows and full column contents
df.show(2,truncate=False) 

# Display 2 rows & column values 25 characters
df.show(2,truncate=10) 

# Display DataFrame rows & columns vertically
df.show(n=3,truncate=10,vertical=True)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from products where price > 1000

# COMMAND ----------

spark.sql("select item_id, name from products where price > '1000'").show()

# COMMAND ----------

dept = [("Finance",10),("Marketing",20),("Sales",30),("IT",40)]
rdd = spark.sparkContext.parallelize(dept)

df = rdd.toDF()
df.printSchema()
df.show(truncate=False)

deptColumns = ["dept_name","dept_id"]
df2 = rdd.toDF(deptColumns)
df2.printSchema()
df2.show(truncate=False)

deptDF = spark.createDataFrame(rdd, schema = deptColumns)
deptDF.printSchema()
deptDF.show(truncate=False)

from pyspark.sql.types import StructType,StructField, StringType
deptSchema = StructType([       
    StructField('dept_name', StringType(), True),
    StructField('dept_id', StringType(), True)
])

deptDF1 = spark.createDataFrame(rdd, schema = deptSchema)
deptDF1.printSchema()
deptDF1.show(truncate=False)

# COMMAND ----------

columns = ["Seqno","Quote"]
data = [("1", "Be the change that you wish to see in the world"),
    ("2", "Everyone thinks of changing the world, but no one thinks of changing himself."),
    ("3", "The purpose of our lives is to be happy."),
    ("4", "Be cool.")]
df = spark.createDataFrame(data,columns)
df.show()

#Display full column contents
df.show(truncate=False)

# Display 2 rows and full column contents
df.show(2,truncate=False) 

# Display 2 rows & column values 25 characters
df.show(2,truncate=25) 

# Display DataFrame rows & columns vertically
df.show(n=3,truncate=25,vertical=True)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Create Column Class Object & Use in DF

# COMMAND ----------

data=[("James",23),("Ann",40)]
df=spark.createDataFrame(data).toDF("name.fname","gender")
df.printSchema()
#root
# |-- name.fname: string (nullable = true)
# |-- gender: long (nullable = true)

# Using DataFrame object (df)
df.select(df.gender).show()
df.select(df["gender"]).show()
#Accessing column name with dot (with backticks)
df.select(df["`name.fname`"]).show()

#Using SQL col() function
from pyspark.sql.functions import col
df.select(col("gender")).show()
#Accessing column name with dot (with backticks)
df.select(col("`name.fname`")).show()

df.createOrReplaceTempView("Data")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Data

# COMMAND ----------

# MAGIC %md 
# MAGIC # PySpark Column Operators

# COMMAND ----------

data=[(100,2,1),(200,3,4),(300,4,4)]
df=spark.createDataFrame(data).toDF("col1","col2","col3")

#Arthmetic operations
df.select(df.col1 + df.col2).show()
df.select(df.col1 - df.col2).show() 
df.select(df.col1 * df.col2).show()
df.select(df.col1 / df.col2).show()
df.select(df.col1 % df.col2).show()

df.select(df.col2 > df.col3).show()
df.select(df.col2 < df.col3).show()
df.select(df.col2 == df.col3).show()