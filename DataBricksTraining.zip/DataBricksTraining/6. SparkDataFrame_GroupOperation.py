# Databricks notebook source
# MAGIC %md
# MAGIC #Base data creations

# COMMAND ----------

simpleData = [("James","Sales","NY",90000,34,10000),
    ("Michael","Sales","NY",86000,56,20000),
    ("Robert","Sales","CA",81000,30,23000),
    ("Maria","Finance","CA",90000,24,23000),
    ("Raman","Finance","CA",99000,40,24000),
    ("Scott","Finance","NY",83000,36,19000),
    ("Jen","Finance","NY",79000,53,15000),
    ("Jeff","Marketing","CA",80000,25,18000),
    ("Kumar","Marketing","NY",91000,50,21000)
  ]

schema = ["employee_name","department","state","salary","age","bonus"]
df = spark.createDataFrame(data=simpleData, schema = schema)
df.printSchema()
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # GroupBy > Sum/Count/AVg/Min/Max

# COMMAND ----------

# Department wise salary distrbution
SalDF = df.groupBy("department").sum("salary")
SalDF.display()

# COMMAND ----------

deptCnt = df.groupBy("department").count()
deptCnt.display()

# COMMAND ----------

from pyspark.sql.functions import sum,avg,max
df.groupBy("department") \
    .agg(sum("salary").alias("sum_salary"), \
         avg("salary").alias("avg_salary"), \
         sum("bonus").alias("sum_bonus"), \
         max("bonus").alias("max_bonus") \
     ) \
    .display()

# COMMAND ----------

from pyspark.sql.functions import sum,avg,max,col

df.groupBy("department") \
    .agg(sum("salary").alias("sum_salary"), \
      avg("salary").alias("avg_salary"), \
      sum("bonus").alias("sum_bonus"), \
      max("bonus").alias("max_bonus")) \
    .where(col("sum_bonus") >= 50000) \
    .show(truncate=False)

# COMMAND ----------

UserName=dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()

df1 = spark.read.format("csv").option("header", "true").load(f"dbfs:/FileStore/shared_uploads/{UserName}/sales.csv")
aggDF = df1.groupBy("order_id","email")\
  .agg(sum("total_item_quantity").alias("qatCnt")).orderBy(col("qatCnt").desc())
aggDF.display()