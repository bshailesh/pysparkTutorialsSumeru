# Databricks notebook source
# MAGIC %md
# MAGIC # Date Transformations - 
# MAGIC   get month, date, year, update date format. months between two dates, days between 2 dates, etc

# COMMAND ----------

from pyspark.sql.functions import *

data=[["1","2020-02-01"],["2","2019-03-01"],["3","2021-03-01"]]
df=spark.createDataFrame(data,["id","input"])
df.display()
df.select(col("input"), current_date().alias("current_date"), 
          date_format(col("input"), "MM-dd-yyyy").alias("date_format"),
          to_date(col("input"), "yyy-MM-dd").alias("to_date"),
          add_months(col("input"),3).alias("add_months"), 
          add_months(col("input"),-3).alias("sub_months"), 
          date_add(col("input"),4).alias("date_add"), 
          date_sub(col("input"),4).alias("date_sub") ) \
  .withColumn("dateDiff", datediff(current_date(),col("input"))) \
  .withColumn("months_between", months_between(current_date(),col("input")))\
  .display()

# COMMAND ----------

df.select(col("input"), 
     year(col("input")).alias("year"), 
     month(col("input")).alias("month"), 
     next_day(col("input"),"Sunday").alias("next_day"), 
     weekofyear(col("input")).alias("weekofyear"),
     dayofweek(col("input")).alias("dayofweek"), 
     dayofmonth(col("input")).alias("dayofmonth"), 
     dayofyear(col("input")).alias("dayofyear")
  ).display()

# COMMAND ----------

data=[["1","2020-02-01 11:01:19.06"],["2","2019-03-01 12:01:19.406"],["3","2021-03-01 12:01:19.406"]]
df3=spark.createDataFrame(data,["id","input"])

df3.select(col("input"), 
    hour(col("input")).alias("hour"), 
    minute(col("input")).alias("minute"),
    second(col("input")).alias("second") 
  ).display()
