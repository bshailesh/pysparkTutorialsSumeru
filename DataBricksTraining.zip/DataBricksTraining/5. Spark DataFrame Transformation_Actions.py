# Databricks notebook source
# MAGIC %md
# MAGIC # DataFrame & Column
# MAGIC 1. Construct columns
# MAGIC 1. Subset columns
# MAGIC 1. Add or replace columns
# MAGIC 1. Subset rows
# MAGIC 1. Sort rows
# MAGIC 
# MAGIC ##### Methods
# MAGIC - DataFrame (<a href="https://spark.apache.org/docs/latest/api/python/pyspark.sql.html?highlight=dataframe#pyspark.sql.DataFrame" target="_blank">Python</a>/<a href="http://spark.apache.org/docs/latest/api/scala/org/apache/spark/sql/Dataset.html" target="_blank">Scala</a>): `select`, `selectExpr`, `drop`, `withColumn`, `withColumnRenamed`, `filter`, `distinct`, `limit`, `sort`
# MAGIC - Column (<a href="https://spark.apache.org/docs/latest/api/python/pyspark.sql.html?highlight=column#pyspark.sql.Column" target="_blank">Python</a>/<a href="http://spark.apache.org/docs/latest/api/scala/org/apache/spark/sql/Column.html" target="_blank">Scala</a>): `alias`, `isin`, `cast`, `isNotNull`, `desc`, operators

# COMMAND ----------

# MAGIC %md
# MAGIC # Username Read and pass as string parameter

# COMMAND ----------

UserName=dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
dataset_path = f"dbfs:/FileStore/shared_uploads/{UserName}/products.csv"
print(UserName)
print(dataset_path)

# COMMAND ----------

products = spark.read.format("csv") \
  .option("header", "true") \
  .option("inferSchema", "true") \
  .load(dataset_path)
products.show()
products.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Collect
# MAGIC PySpark RDD/DataFrame collect() is an action operation that is used to retrieve all the elements of the dataset (from all nodes) to the driver node. We should use the collect() on smaller dataset usually after filter(), group() e.t.c. Retrieving larger datasets results in OutOfMemory error.

# COMMAND ----------

dataCollect = products.collect()
print(dataCollect)

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter operations

# COMMAND ----------

products.filter(products.price > "1000").display()

# COMMAND ----------

products.createOrReplaceTempView("products")
spark.sql("select item_id, name from products where price > '1000' ").show()

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField, StringType, IntegerType, ArrayType
from pyspark.sql.functions import col,array_contains, expr, lit

arrayStructureData = [
        (("James","","Smith"),["Java","Scala","C++"],"OH","M"),
        (("Anna","Rose",""),["Spark","Java","C++"],"NY","F"),
        (("Julia","","Williams"),["CSharp","VB"],"OH","F"),
        (("Maria","Anne","Jones"),["CSharp","VB"],"NY","M"),
        (("Jen","Mary","Brown"),["CSharp","VB"],"NY","M"),
        (("Mike","Mary","Williams"),["Python","VB"],"OH","M")
        ]
        
arrayStructureSchema = StructType([
        StructField('name', StructType([
             StructField('firstname', StringType(), True),
             StructField('middlename', StringType(), True),
             StructField('lastname', StringType(), True)
             ])),
         StructField('languages', ArrayType(StringType()), True),
         StructField('state', StringType(), True),
         StructField('gender', StringType(), True)
         ])


df = spark.createDataFrame(data = arrayStructureData, schema = arrayStructureSchema)
df.printSchema()
df.show(truncate=False)

df.filter(df.state == "OH") \
    .show(truncate=False)

df.filter(col("state") == "OH") \
    .show(truncate=False)    
    
df.filter("gender  == 'M'") \
    .show(truncate=False)    

df.filter( (df.state  == "OH") & (df.gender  == "M") ) \
    .show(truncate=False)        

df.filter(array_contains(df.languages,"Java")) \
    .show(truncate=False)        

df.filter(df.name.lastname == "Williams") \
    .show(truncate=False) 

# Using startswith
df.filter(df.state.startswith("N")).show()

#using endswith
df.filter(df.state.endswith("H")).show()

#contains
df.filter(df.state.contains("H")).show()

# COMMAND ----------

# MAGIC %md
# MAGIC # WithColumn & withColumnRename & lit

# COMMAND ----------

#products.withColumnRenamed("price","salePrice").withColumn("Country", lit("USA")).withColumn("regPrice", col("salePrice") - 100 ).display()
products.withColumn("Country", lit("India")).withColumnRenamed("price","basePrice").withColumn("salePrice", col("basePrice") * 2 ).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Drop 

# COMMAND ----------

products.withColumn("Country", lit("India"))\
.withColumnRenamed("price","basePrice")\
.withColumn("salePrice", col("basePrice") * 2 )\
.drop("basePrice","Country").display()

# COMMAND ----------

# MAGIC %md
# MAGIC # DropDuplicate

# COMMAND ----------

# Import pySpark
from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# Prepare Data
salData = [("James", "Sales", 3000), \
    ("Michael", "Sales", 4600), \
    ("Robert", "Sales", 4100), \
    ("Maria", "Finance", 3000), \
    ("James", "Sales", 3000), \
    ("Scott", "Finance", 3300), \
    ("Jen", "Finance", 3900), \
    ("Jeff", "Marketing", 3000), \
    ("Kumar", "Marketing", 2000), \
    ("Saif", "Sales", 4100) \
  ]

# Create DataFrame
columns= ["employee_name", "department", "salary"]
salData = spark.createDataFrame(data = salData, schema = columns)
print("Sal Data Count : " + str(salData.count()))
salData.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # distinct & DrpDuplicate

# COMMAND ----------

distinctDF = salData.distinct()
print("Distinct count: "+str(distinctDF.count()))

df2 = salData.dropDuplicates()
print("Distinct count: "+str(df2.count()))

dropDisDF = salData.dropDuplicates(["department","salary"])
print("Distinct count of department & salary : "+str(dropDisDF.count()))

# COMMAND ----------

# MAGIC %md
# MAGIC # sort with and without col >>>> asc & Desc

# COMMAND ----------

salData.sort("department","salary").show(truncate=False)
salData.sort(col("department").asc(),col("salary").desc()).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # OrderBy

# COMMAND ----------

salData.orderBy("department","salary").show(truncate=False)
salData.orderBy(col("department"),col("salary").desc()).display()